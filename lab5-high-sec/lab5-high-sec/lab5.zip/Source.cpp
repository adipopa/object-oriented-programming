#include "Console.h"

int main() {
	RecordingRepository recordingRepository{};
	RecordingValidator recordingValidator{ &recordingRepository };
	RecordingController recordingController{ &recordingValidator, &recordingRepository };
	Console console{ &recordingController };
	console.runConsole();
	return 0;
}