#include "lab11convergence.h"
#include "RecordingModel.h"
#include <QtWidgets/QApplication>
#include <QSortFilterProxyModel>
#include <QTableView>
#include <QHeaderView>

int main(int argc, char *argv[]) {
	QApplication application(argc, argv);

	std::shared_ptr<RecordingRepository> recordingRepository = std::make_shared<RecordingRepository>();
	std::shared_ptr<WatchlistRepository> watchlistRepository = std::make_shared<WatchlistRepository>();
	std::shared_ptr<RecordingValidator> recordingValidator = std::make_shared<RecordingValidator>(recordingRepository, watchlistRepository);
	std::shared_ptr<RecordingController> recordingController = std::make_shared<RecordingController>(
		recordingValidator, recordingRepository, watchlistRepository, "high-security"
	);

	recordingController->setFileLocation(".\\TestInput.txt");

	RecordingModel* recordingModel = new RecordingModel{ recordingController };

	QTableView* tableView = new QTableView{};

	QSortFilterProxyModel* proxyModel = new QSortFilterProxyModel{};
	proxyModel->setSourceModel(recordingModel);

	tableView->setModel(proxyModel);

	tableView->setWindowTitle("High-sec clearance - Argo");
	tableView->setSortingEnabled(true);
	tableView->sortByColumn(0, Qt::AscendingOrder);
	tableView->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
	tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
	tableView->setMinimumSize(924, 420);

	tableView->show();

	return application.exec();
}
