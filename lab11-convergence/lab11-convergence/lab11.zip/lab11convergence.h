#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_lab11convergence.h"

class lab11convergence : public QMainWindow
{
	Q_OBJECT

public:
	lab11convergence(QWidget *parent = Q_NULLPTR);

private:
	Ui::lab11convergenceClass ui;
};
