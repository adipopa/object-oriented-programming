#include "lab11convergence.h"

lab11convergence::lab11convergence(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
}
