#include "WatchlistFakeRepository.h"

WatchlistFakeRepository::WatchlistFakeRepository() : WatchlistRepository{} {}

WatchlistFakeRepository::~WatchlistFakeRepository() {}
